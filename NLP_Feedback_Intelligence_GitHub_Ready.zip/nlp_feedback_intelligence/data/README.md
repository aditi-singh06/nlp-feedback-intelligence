Place only properly licensed/public datasets here.
Expected columns for the starter baseline:
- text
- label

Do not commit private, personally identifiable, confidential, or restricted data.
